<?php 


//definimos la codificación de los caracteres
define("DB_ENCODE","utf8");

//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","Mckenneth");

/* Servidor Local */
//Ip de la pc servidor de base de datos
define("DB_HOST","localhost");

//Nombre de la base de datos
define("DB_NAME", "riverare_puntoventadb");

//Usuario de la base de datos
define("DB_USERNAME", "riverare_puntoventaus");

//Contraseña del usuario de la base de datos
define("DB_PASSWORD", "5zm)XSY?h)k?");


const URL = "https://floresrivera.com/proyectos/ingefact";

const SPD = ".";
const SPM = ",";
const MMONEY = "S/";

	//Datos envio de correo
	const EMAIL = "aldosantiniss@gmail.com";
	const NOMBRE_REMITENTE = "Tienda Virtual";
	const EMAIL_REMITENTE = "no-reply@gruposantini.com";
	const NOMBRE_EMPRESA = "MI NEGOCIO SAC";
	const ADDRESS = "AV. GARCILASOD DE LA VEGA  ";
	const ADDRESS2 = "No 147 CERCADO DE LIMA - LIMA ";
	const RUC = "20123456789";
	const NOMBRE_EMPRESA_SLUG = "G-S";
	const WEB_EMPRESA = "www.floresrivera.com";
/* 	+1 (954) 630-5627 */

	const EMAIL_RECIBE = "oswaldoelflori@gmail.com";

	const CODIGO = "51";
	const CELULAR1 = "938222552";
	const CELULAR2 = "938 222 552";
	const PAIS = "+51";

	//SEO

	const T_SEO = "ARAPAIMA EXPEDITIONS tours por el Perú ";
	const D_SEO = "Arapaima Paquetes Turisticos en Perú, viajes a todo el Perú, Tour en Lima";


    

/* Servidor Produccion */

// define("DB_HOST","localhost");

/* //Nombre de la base de datos
define("DB_NAME", "ab6952_corego");

//Usuario de la base de datos
define("DB_USERNAME", "ab6952_coregou");

//Contraseña del usuario de la base de datos
define("DB_PASSWORD", "}cB5ekHmb0zt"); */




?>